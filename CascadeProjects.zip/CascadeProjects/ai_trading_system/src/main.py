import asyncio
import uvicorn
from api.main import app
from database.init_db import init_database
import logging
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/trading.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

async def startup():
    """Initialize the application."""
    try:
        # Create logs directory if it doesn't exist
        Path('logs').mkdir(exist_ok=True)
        
        # Initialize database
        logger.info("Initializing database...")
        engine, SessionLocal = init_database()
        
        logger.info("AI Trading System initialized successfully!")
        return True
    except Exception as e:
        logger.error(f"Error during startup: {str(e)}")
        return False

def main():
    """Main entry point for the application."""
    try:
        # Run startup tasks
        asyncio.run(startup())
        
        # Start the FastAPI server
        logger.info("Starting API server...")
        uvicorn.run(
            app,
            host="0.0.0.0",
            port=8000,
            log_level="info"
        )
    except Exception as e:
        logger.error(f"Application error: {str(e)}")
        raise

if __name__ == "__main__":
    main()
