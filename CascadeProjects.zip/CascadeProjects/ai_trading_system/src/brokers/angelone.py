from typing import Dict, List, Optional
from datetime import datetime
from smartapi import SmartConnect
from .base import BaseBroker

class AngelOneBroker(BaseBroker):
    """Angel One broker implementation using Smart API."""
    
    def __init__(self, api_key: str, api_secret: str, client_code: str):
        super().__init__(api_key, api_secret)
        self.client_code = client_code
        self.smart_api = None
        self.feed_token = None
    
    async def connect(self) -> bool:
        """Connect to Angel One API."""
        try:
            self.smart_api = SmartConnect(api_key=self.api_key)
            data = self.smart_api.generateSession(self.client_code, self.api_secret)
            self.feed_token = data['data']['feedToken']
            
            # Verify connection
            profile = self.smart_api.getProfile(self.feed_token)
            if profile['status']:
                self.is_connected = True
                return True
            return False
        except Exception as e:
            print(f"Error connecting to Angel One: {str(e)}")
            return False
    
    async def disconnect(self) -> bool:
        """Disconnect from Angel One API."""
        try:
            if self.smart_api:
                self.smart_api.terminateSession(self.client_code)
            self.is_connected = False
            return True
        except Exception as e:
            print(f"Error disconnecting from Angel One: {str(e)}")
            return False
    
    async def get_account_info(self) -> Dict:
        """Get account information."""
        try:
            rms_data = self.smart_api.rmsLimit()['data']
            return {
                'balance': float(rms_data['availablecash']),
                'used_margin': float(rms_data['utilizedamount']),
                'available_margin': float(rms_data['net'])
            }
        except Exception as e:
            print(f"Error getting account info: {str(e)}")
            return {}
    
    async def place_order(self, symbol: str, side: str, quantity: float,
                         order_type: str = 'MARKET', price: Optional[float] = None) -> Dict:
        """Place a new order."""
        try:
            order_params = {
                "variety": "NORMAL",
                "tradingsymbol": self.format_symbol(symbol),
                "symboltoken": self._get_token(symbol),
                "transactiontype": "BUY" if side.upper() == "BUY" else "SELL",
                "exchange": "NSE",
                "ordertype": order_type.upper(),
                "producttype": "INTRADAY",
                "duration": "DAY",
                "quantity": int(quantity)
            }
            
            if order_type.upper() == "LIMIT" and price:
                order_params["price"] = str(price)
            
            response = self.smart_api.placeOrder(order_params)
            
            if response['status']:
                order_id = response['data']['orderid']
                return {
                    'order_id': order_id,
                    'status': 'PLACED',
                    'symbol': symbol,
                    'quantity': quantity,
                    'side': side,
                    'type': order_type,
                    'price': price
                }
            return {}
        except Exception as e:
            print(f"Error placing order: {str(e)}")
            return {}
    
    async def cancel_order(self, order_id: str) -> bool:
        """Cancel an existing order."""
        try:
            response = self.smart_api.cancelOrder(order_id, "NORMAL")
            return response['status']
        except Exception as e:
            print(f"Error canceling order: {str(e)}")
            return False
    
    async def get_order_status(self, order_id: str) -> Dict:
        """Get status of an order."""
        try:
            orders = self.smart_api.orderBook()['data']
            order = next((o for o in orders if o['orderid'] == order_id), None)
            
            if order:
                return {
                    'order_id': order['orderid'],
                    'status': order['orderstatus'],
                    'filled_quantity': int(order['filledshares']),
                    'remaining_quantity': int(order['unfilledshares']),
                    'average_price': float(order['averageprice'])
                }
            return {}
        except Exception as e:
            print(f"Error getting order status: {str(e)}")
            return {}
    
    async def get_positions(self) -> List[Dict]:
        """Get current positions."""
        try:
            positions = self.smart_api.position()['data']
            return [{
                'symbol': pos['tradingsymbol'],
                'quantity': int(pos['netqty']),
                'average_price': float(pos['averageprice']),
                'current_price': float(pos['ltp']),
                'pnl': float(pos['pnl'])
            } for pos in positions]
        except Exception as e:
            print(f"Error getting positions: {str(e)}")
            return []
    
    async def get_market_data(self, symbol: str, interval: str = 'ONE_MINUTE',
                            start_time: Optional[datetime] = None,
                            end_time: Optional[datetime] = None) -> List[Dict]:
        """Get historical market data."""
        try:
            # Convert interval to Angel One format
            interval_map = {
                'minute': 'ONE_MINUTE',
                '5minute': 'FIVE_MINUTE',
                '15minute': 'FIFTEEN_MINUTE',
                'hour': 'ONE_HOUR',
                'day': 'ONE_DAY'
            }
            
            token = self._get_token(symbol)
            
            params = {
                "exchange": "NSE",
                "symboltoken": token,
                "interval": interval_map.get(interval, 'ONE_MINUTE'),
                "fromdate": start_time.strftime("%Y-%m-%d %H:%M") if start_time else None,
                "todate": end_time.strftime("%Y-%m-%d %H:%M") if end_time else None
            }
            
            candles = self.smart_api.getCandleData(params)['data']
            
            return [{
                'timestamp': candle[0],
                'open': float(candle[1]),
                'high': float(candle[2]),
                'low': float(candle[3]),
                'close': float(candle[4]),
                'volume': float(candle[5])
            } for candle in candles]
        except Exception as e:
            print(f"Error getting market data: {str(e)}")
            return []
    
    async def get_ticker(self, symbol: str) -> Dict:
        """Get current market price for a symbol."""
        try:
            token = self._get_token(symbol)
            quote = self.smart_api.ltpData("NSE", symbol, token)['data']
            
            return {
                'symbol': symbol,
                'last_price': float(quote['ltp']),
                'volume': float(quote.get('volume', 0)),
                'change': float(quote.get('change', 0)),
                'exchange': quote['exchange'],
                'token': quote['token']
            }
        except Exception as e:
            print(f"Error getting ticker: {str(e)}")
            return {}
    
    async def get_exchange_info(self) -> Dict:
        """Get exchange information."""
        try:
            response = self.smart_api.exchangeInfo()
            return {
                'exchange_status': response['data']['exchangestatus'],
                'market_type': response['data']['markettype'],
                'exchange_timezone': response['data']['exchangetimezone']
            }
        except Exception as e:
            print(f"Error getting exchange info: {str(e)}")
            return {}
    
    def format_symbol(self, symbol: str) -> str:
        """Format symbol according to Angel One requirements."""
        # Angel One uses simple symbol names
        return symbol.upper()
    
    def _get_token(self, symbol: str) -> str:
        """Get token for a symbol."""
        try:
            response = self.smart_api.searchScrip(symbol)
            if response['status']:
                return response['data'][0]['token']
            return ""
        except Exception:
            return ""
    
    async def subscribe_to_market_data(self, symbols: List[str], callback) -> bool:
        """Subscribe to real-time market data."""
        try:
            tokens = [self._get_token(s) for s in symbols]
            
            def on_message(ws, message):
                callback(message)
            
            def on_open(ws):
                ws.subscribe(tokens)
                ws.set_mode(ws.MODE_LTP, tokens)
            
            self.smart_api.start_websocket(
                subscribe_callback=on_message,
                socket_open_callback=on_open
            )
            
            return True
        except Exception as e:
            print(f"Error subscribing to market data: {str(e)}")
            return False
    
    async def unsubscribe_from_market_data(self, symbols: List[str]) -> bool:
        """Unsubscribe from real-time market data."""
        try:
            tokens = [self._get_token(s) for s in symbols]
            self.smart_api.ws.unsubscribe(tokens)
            return True
        except Exception as e:
            print(f"Error unsubscribing from market data: {str(e)}")
            return False
