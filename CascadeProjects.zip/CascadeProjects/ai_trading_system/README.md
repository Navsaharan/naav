# AI-Powered Trading System

A comprehensive AI-powered trading system supporting multiple asset classes and brokers with advanced features for automated trading.

## Features

- Multi-Broker API Integration
- Smart AI Trading & Strategy System
- Paper Trading Simulation
- AI Risk Management
- Sentiment & News Analysis
- Manual & AI-Assisted Trading
- Admin Panel
- High-Performance Infrastructure

## Setup

1. Clone the repository
2. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```
3. Install dependencies:
```bash
pip install -r requirements.txt
```
4. Set up environment variables in `.env` file
5. Initialize the database:
```bash
python src/database/init_db.py
```
6. Start the application:
```bash
python src/main.py
```

## Project Structure

```
ai_trading_system/
├── src/
│   ├── api/              # API endpoints
│   ├── core/             # Core trading engine
│   ├── models/           # AI/ML models
│   ├── brokers/          # Broker integrations
│   ├── database/         # Database models and operations
│   ├── services/         # Business logic
│   ├── utils/            # Utility functions
│   └── web/             # Web interface
├── tests/               # Test cases
├── docs/               # Documentation
└── config/            # Configuration files
```

## Security Note

This system follows all legal trading guidelines and regulations. Users must:
- Provide their own API keys
- Accept terms and conditions
- Acknowledge trading risks
- Follow local trading laws and regulations

## License

MIT License - See LICENSE file for details
